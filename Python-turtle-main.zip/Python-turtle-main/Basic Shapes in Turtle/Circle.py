#circle

import turtle  
# Creating turtle screen  
t = turtle.Turtle()  
  
t.circle(50)  
  
turtle.mainloop()  



#Dot
# Creating turtle screen  
t = turtle.Turtle()  
  
t.dot(50)  
  
turtle.mainloop()  
