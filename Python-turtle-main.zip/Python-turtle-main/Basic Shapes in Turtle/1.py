

from turtle import*
speed(4)
lt(30)
fd(100)
bk(100)
rt(60)
fd(100)
bk(100)
lt(30)
bk(100)
rt(90)
fd(30)
bk(60)



hideturtle()
done()
