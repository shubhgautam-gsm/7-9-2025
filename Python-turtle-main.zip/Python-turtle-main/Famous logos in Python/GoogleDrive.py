#Google drive logo in Python

import turtle as t 
t.hideturtle()

#blue
t.begin_fill()
t.fillcolor('blue')
t.forward(170)
t.left(60)
t.forward(50)
t.left(120)
t.forward(220)
t.left(120)
t.forward(50)
t.end_fill()


#green
t.begin_fill()
t.fillcolor('green')
t.left(120)
t.forward(200)
t.left(120)
t.forward(50)
t.left(60)
t.forward(150)
t.left(60)
t.forward(50)
t.end_fill()


t.penup()
t.left(120)
t.forward(200)
t.left(120)
t.forward(50)
t.pendown()

#yellow
t.begin_fill()
t.fillcolor('yellow')
t.left(125)
t.forward(160)
t.left(55)
t.forward(53)
t.left(126)
t.forward(163)
t.end_fill()


t.done()
