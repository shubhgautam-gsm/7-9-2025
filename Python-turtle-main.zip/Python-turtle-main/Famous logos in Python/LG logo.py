#LG logo in Python turtle

from turtle import *
color("#990033")
dot(300)
up()
goto(0,120)
down()
color("white")
width(10)
left(180)

circle(120,270)
left(90)
fd(80)
up()
goto(-40,50)
down()
dot(30)

up()
goto(0,60)
down()
left(90)
fd(120)
lt(90)
fd(40)

done()
