#linkedin logo in Pytohn
from turtle import *
speed(5)
color("blue")
pensize(10)
begin_fill()
for i in range(4):
    fd(165)
    lt(90)
end_fill()
pu()
fd(90)
rt(90)
fd(40)
color("white")
write("in", move = False, align = "center", font= ("Century Gothic",152,"bold"))
done()
