#phone pay logo in Python turtle

from turtle import *
bgcolor("black")
speed(1)
hue = 0.0

width(20)


up()
goto(-50,-70)
down()
begin_fill()
color("#6739b7")
t.circle(200)
end_fill()

up()
color('white')
goto(-110,200)
down()
rt(90)
fd(90)
circle(25,45)
fd(5)
lt(45)
fd(60)
circle(25,45)
fd(5)
lt(45)
fd(95)
bk(180)
 
    
up()
goto(-170,200)
down()
rt(90)
fd(180)
up()
goto(-20,200)
down()
lt(130)
fd(120)
ht()
done()
