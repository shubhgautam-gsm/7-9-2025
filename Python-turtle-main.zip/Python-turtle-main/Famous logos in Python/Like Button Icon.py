#like button icon in python

from turtle import *
speed(4)
width(5)
pu()
goto(-100,-100)
pd()
for i in range(2):
    fd(100)
    lt(90)
    fd(200)
    lt(90)
fd(300)
circle(20,70)
fd(160)
circle(20,110)
fd(140)
rt(100)
fd(140)
circle(20,155)
fd(175)
ht()
done()
