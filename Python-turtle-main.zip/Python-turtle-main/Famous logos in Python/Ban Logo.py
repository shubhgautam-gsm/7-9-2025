#ban logo in Pytohn
from turtle import *

pensize(40)
color("red")
fillcolor("white")
begin_fill()
circle(150)
end_fill()
pu()
goto(83,50)
pd()
pensize(30)
lt(130)
fd(280)
ht()
done()
