
#SBi logo in Python
from turtle import *

def main():
    up()
    goto(0,-170)
    color("#2a9df4")
    begin_fill()
    down()
    circle(170)
    end_fill()
    lt(90)
    width(20)
    color("white")
    fd(190)
    lt(90)
    circle(20)
    up()
    
    
if __name__ == '__main__':
    main()
    
    
ht()
done()
