#mastercard logo in Python

from turtle import *
speed(8)
pu()
goto(-70,-100)
pd()
color("#EB001B")
begin_fill()
circle(100)
end_fill()

pu()
goto(70,-100)
pd()
color("#F79E1B")
begin_fill()
circle(100)
end_fill()
circle(100,225)
color("#FF5F00")
begin_fill()
circle(100,90)
lt(90)
circle(100,90)
end_fill()

ht()
done()
