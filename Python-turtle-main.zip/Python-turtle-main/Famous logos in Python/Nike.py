#Nike logo in Pytohn turtle

from turtle import *
color('white')
bgcolor('black')
ht()
lt(180)
up()
circle(30,10)
down()
begin_fill()
circle(30,190)
fd(200)
lt(173)
fd(190)
circle(-18,170)
end_fill()
done()
