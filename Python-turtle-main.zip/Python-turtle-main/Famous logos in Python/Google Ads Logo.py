#google ads icon in Pytohn


from turtle import *
speed(3)
width(1)
pu()
goto(-130,-100)
pd()
lt(60)
color("#FBBC05")
begin_fill()
for i in range(2):
    fd(300)
    circle(75,180)
end_fill()
color("#34A853")
begin_fill()
circle(75)
end_fill()
pu()
goto(170,-25)
color("#4285F4")
begin_fill()
lt(60)
pd()
for i in range(2):
    fd(300)
    circle(75,180)
end_fill()
ht()
done()
