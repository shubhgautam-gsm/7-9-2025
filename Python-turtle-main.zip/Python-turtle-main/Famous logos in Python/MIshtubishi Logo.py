#Mishtubishi logo in Pytohn
from turtle import *
speed(6)
color("darkred")
begin_fill()
for i in range(3):
    for i in range(2):
        fd(100)
        rt(60)
        fd(100)
        rt(120)
    rt(120)
end_fill()
ht()
done()
