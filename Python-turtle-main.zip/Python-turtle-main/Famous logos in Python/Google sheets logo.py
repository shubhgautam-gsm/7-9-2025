#google sheets logo in Python

from turtle import *

speed(6)

width(1)

pu()

goto(-60,-100)

pd()

color("#18ad18")

begin_fill()

fd(120)

circle(15,90)

fd(135)

lt(90)

fd(50)

rt(90)

fd(50)

lt(90)

fd(85)

circle(15,90)

fd(170)

circle(15,90)

end_fill()

goto(75,50)

color("#115e11")

begin_fill()

lt(135)

fd(70)

lt(135)

fd(50)

lt(90)

fd(50)

end_fill()

pu()

goto(-40,20)

pd()

color("white")

begin_fill()

fd(80)

rt(90)

fd(60)

rt(90)

fd(80)

rt(90)

fd(60)

rt(90)

end_fill()

pu()

goto(-30,10)

pd()

color("#18ad18")

begin_fill()

fd(60)

rt(90)

fd(40)

rt(90)

fd(60)

rt(90)

fd(40)

rt(90)

end_fill()

pencolor("white")

width(9)

pu()

goto(-30,-11)

pd()

fd(60)

rt(90)

pu()

goto(0,10)

pd()

fd(40)

ht()

done()
