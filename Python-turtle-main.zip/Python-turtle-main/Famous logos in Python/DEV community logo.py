#devto logo in python

from turtle import *

bgcolor('white')

pencolor('black')

width(3)

pu()

goto(150,350)

pd()

rt(180)

begin_fill()

color("black")

forward(450)

circle(34,90)

fd(200)

circle(34,90)

forward(450)

circle(34,90)

fd(200)

circle(34,90)

 

 

 

pu()

goto(-330,40)

pd()

end_fill()

color("white")    

write("DEV", move = False, font= ("Arial",48,"bold"))

done()
