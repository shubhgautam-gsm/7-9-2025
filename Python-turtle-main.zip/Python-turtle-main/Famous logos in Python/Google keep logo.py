# Google keep - notes and lists logo in python



from turtle import *

speed(6)

width(1)

pu()

goto(-60,-100)

pd()

color("orange")

begin_fill()

fd(120)

circle(15,90)

fd(135)

lt(90)

fd(50)

rt(90)

fd(50)

lt(90)

fd(85)

circle(15,90)

fd(170)

circle(15,90)

end_fill()

goto(75,50)

color("#ef5603")

begin_fill()

lt(135)

fd(70)

lt(135)

fd(50)

lt(90)

fd(50)

end_fill()

pu()

goto(-40,20)

pd()

color("white")

pu()

goto(3,-27)

pd()

begin_fill()

circle(30)

end_fill()

color("orange")

pu()

goto(-16,-29)

pd()

width(13)

fd(39)

color("white")

pu()

goto(-8,-31)

pd()

width(6)

fd(20)

ht()

done()
