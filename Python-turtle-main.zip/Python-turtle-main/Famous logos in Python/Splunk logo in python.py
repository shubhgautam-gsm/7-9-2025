#splunk logo in Python

from turtle import *

pu()

goto(-500,0)

pd()

write("splunk",font=("Times Now",50,"normal"))

pu()

goto(330,70)

pd()

pencolor("#4CBB17")

fillcolor("#4CBB17")

begin_fill()

fd(1)

rt(90)

fd(50)

rt(-150)

fd(125)

rt(-30)

fd(50)

end_fill()

pu()

goto(391,178)

pd()

begin_fill()

fd(-50)

rt(150)

fd(-125)

rt(30)

fd(-50)

end_fill()

ht()

done()
