#google pixel birds logo in Pytohn

from turtle import *

color("green")
pu()
goto(-20,10)
pd()
rt(-55)
width(15)
circle(30,80)


color("#00a4df")
pu()
rt(90)
goto(3.5,-30)
pd()
width(13)
circle(80,90)


color("#ef9503")
pu()
goto(80,-30)
pd()
rt(180)
width(13)
circle(80,-90)



color("red")
pu()
goto(105,45)
pd()
rt(8)
width(13)
circle(30,85)



ht()
done()
