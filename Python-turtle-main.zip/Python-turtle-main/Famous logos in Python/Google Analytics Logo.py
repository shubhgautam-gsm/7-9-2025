#Google Analytics logo in Python

from turtle import *

bgcolor('white')
color("#d22304")
pu()
goto(-13,2)
begin_fill()
dot(20)
end_fill()
pd()


color("#df4e00")
width(19)
rt(90)
pu()
goto(15,35)
pd()
fd(33)


color("#f39e00")
width(19)
pu()
goto(45,70)
pd()
fd(70)

ht()
done()
