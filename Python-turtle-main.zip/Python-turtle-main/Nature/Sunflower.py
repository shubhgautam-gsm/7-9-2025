#Program:
#sunflower using turtle
import turtle

tur = turtle.Turtle()
tur.speed(20)
tur.color("black", "orange")
tur.begin_fill()

for i in range(50):
	tur.forward(300)
	tur.left(170)

tur.end_fill()
turtle.done()
