#flag of Bangla desh in Python 
from turtle import *

speed(0)
setup(800, 500)
bgcolor("seagreen")

penup()
goto(-100, -100)
pendown()

color("red")
begin_fill()
circle(120)
end_fill()

hideturtle()
done()
