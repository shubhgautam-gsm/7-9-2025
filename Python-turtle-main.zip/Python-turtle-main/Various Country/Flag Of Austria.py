#flag of Austria
from turtle import *

speed(0)
setup(800, 500)
bgcolor("red")

penup()
goto(-400, -80)
pendown()

color("white")
begin_fill()
forward(800)
left(90)
forward(167)
left(90)
forward(800)
end_fill()

hideturtle()
done()
