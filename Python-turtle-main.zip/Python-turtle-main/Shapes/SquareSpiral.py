import turtle

squary = turtle.Turtle()
squary.speed(10)

for i in range(500): # this "for" loop will repeat these functions 500 times
    squary.forward(i)
    squary.left(91)
